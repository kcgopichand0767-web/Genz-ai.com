"use client"

import { ArrowUpRight, Clock3, Menu, Search, Sparkles, TrendingUp, X } from 'lucide-react'
import { useState } from 'react'

const articles = [
  { category: 'We Shop AI', title: 'The art of writing cinematic prompts that actually work', excerpt: 'A practical field guide to camera language, motion, and atmosphere for your next AI film.', meta: '8 min read', image: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1000&q=85' },
  { category: 'Tutorial', title: 'Turn one image into a living, breathing scene', excerpt: 'Build momentum into still frames with repeatable motion recipes for Pika and Runway.', meta: '6 min read', image: 'https://images.unsplash.com/photo-1534791547706-3c7f9f3f2f76?auto=format&fit=crop&w=1000&q=85' },
  { category: 'Sora AI', title: 'A beginner workflow for AI video in 2025', excerpt: 'From rough idea to polished cut: the tools and steps that keep your process moving.', meta: '10 min read', image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=1000&q=85' },
  { category: 'Prompt Lab', title: 'Directing dream sequences with next-gen models', excerpt: 'Use surreal transitions and intentional visual anchors to make the impossible feel real.', meta: '7 min read', image: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1000&q=80' },
  { category: 'AI News', title: 'What multimodal models mean for creative people', excerpt: 'The latest shifts in AI are changing how we think, sketch, and ship creative work.', meta: '5 min read', image: 'https://images.unsplash.com/photo-1487887235947-a955ef187fcc?auto=format&fit=crop&w=1000&q=85' },
  { category: 'Pika', title: 'Build a visual world that stays coherent', excerpt: 'A prompt system for characters, locations, and details that stay consistent shot to shot.', meta: '9 min read', image: 'https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1000&q=75' },
]

const trending = ['100 cinematic prompts for Sora', 'The ultimate AI image upscaler guide', 'How to make AI voices sound human', 'Prompt anatomy: from vague to vivid']

function ArticleCard({ article }: { article: (typeof articles)[number] }) {
  return (
    <article className="article-card group">
      <div className="article-image-wrap">
        <img src={article.image} alt="Abstract futuristic AI artwork" className="article-image" />
        <div className="image-shade" />
        <span className="article-number">GENZ / 0{articles.indexOf(article) + 1}</span>
        <span className="article-badge">{article.category}</span>
        <ArrowUpRight className="image-arrow" aria-hidden="true" />
      </div>
      <div className="flex flex-1 flex-col gap-4 p-5">
        <h3 className="text-pretty font-mono text-lg font-bold leading-snug text-card-foreground transition-colors group-hover:text-primary">{article.title}</h3>
        <p className="text-sm leading-6 text-muted-foreground">{article.excerpt}</p>
        <div className="mt-auto flex items-center justify-between border-t border-border/70 pt-4">
          <span className="flex items-center gap-1.5 text-xs text-muted-foreground"><Clock3 className="size-3.5" />{article.meta}</span>
          <button className="read-more" type="button">Read more <ArrowUpRight className="size-3.5" /></button>
        </div>
      </div>
    </article>
  )
}

export default function Page() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <main className="min-h-screen overflow-hidden bg-background text-foreground">
      <div className="cyber-grid" aria-hidden="true" />
      <div className="site-noise" aria-hidden="true" />
      <header className="sticky top-0 z-30 border-b border-border/70 bg-background/70 backdrop-blur-2xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-5 px-5 py-4 lg:px-8">
          <a href="#top" className="logo-word"><span className="logo-icon"><Sparkles className="size-4" /></span>GenZ<span>AI</span></a>
          <nav className={`${menuOpen ? 'flex' : 'hidden'} absolute left-5 right-5 top-16 flex-col gap-4 rounded-2xl border border-border bg-card/95 p-5 shadow-2xl backdrop-blur-xl lg:static lg:flex lg:flex-row lg:items-center lg:gap-7 lg:border-0 lg:bg-transparent lg:p-0 lg:shadow-none`} aria-label="Primary navigation">
            <a href="#articles" className="nav-link">Cinematic Prompts</a><a href="#articles" className="nav-link">Sora AI</a><a href="#articles" className="nav-link">Pika</a><a href="#about" className="nav-link">Tools</a>
          </nav>
          <div className="flex items-center gap-3">
            <label className="search-box"><Search className="size-4 shrink-0" /><span className="sr-only">Search articles</span><input aria-label="Search articles" placeholder="Search" type="search" /></label>
            <button className="menu-button lg:hidden" type="button" aria-label={menuOpen ? 'Close menu' : 'Open menu'} onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button>
          </div>
        </div>
      </header>

      <div id="top" className="relative mx-auto max-w-7xl px-5 lg:px-8">
        <section className="hero-section">
          <div className="hero-orb" aria-hidden="true" />
          <div className="relative z-10 flex flex-col items-start gap-7">
            <div className="eyebrow"><span className="live-dot" /> The future is being prompted</div>
            <h1 className="hero-title">Unlock <span>next-gen</span><br />AI video prompts.</h1>
            <p className="max-w-xl text-pretty text-base leading-7 text-muted-foreground sm:text-lg">A creative intelligence lab for makers shaping new worlds with generative AI. Discover the prompts, workflows, and tools behind the next visual era.</p>
            <a href="#articles" className="hero-button">Explore prompts <ArrowUpRight className="size-4" /></a>
          </div>
          <div className="hero-card" role="img" aria-label="Futuristic neon city created with AI">
            <img src="https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1400&q=90" alt="Futuristic neon city" className="hero-image" /><div className="hero-image-overlay" /><div className="hero-card-copy"><span>01 / SIGNAL LOST</span><strong>Neon<br />Afterimage</strong><small>Generated visual study · 2049</small></div><div className="hero-hud">AI-04 <span>●</span></div>
          </div>
        </section>

        <div className="content-layout">
          <section id="articles">
            <div className="section-heading"><div><p className="eyebrow">The latest dispatches</p><h2>Ideas in motion.</h2></div><span className="story-count">06 / 24 stories</span></div>
            <div className="article-grid">{articles.map((article) => <ArticleCard key={article.title} article={article} />)}</div>
          </section>

          <aside className="sidebar">
            <section className="glass-panel"><div className="widget-heading"><TrendingUp className="size-4 text-primary" /><h2>Trending prompts</h2></div><ol className="trending-list">{trending.map((item, index) => <li key={item}><span>0{index + 1}</span><a href="#articles">{item}</a></li>)}</ol></section>
            <div className="adsense-3d"><span>ADVERTISEMENT</span><strong>GOOGLE ADSENSE<br />BANNER PLACEHOLDER</strong><small>300 × 250</small></div>
            <section className="newsletter glass-panel"><Sparkles className="mb-5 size-5 text-accent" /><h2>Stay in the loop.</h2><p>One sharp dose of AI creativity, sent every Friday.</p><div className="email-row"><input type="email" placeholder="you@email.com" aria-label="Email address" /><button type="button">Join</button></div></section>
          </aside>
        </div>
      </div>

      <footer id="about" className="border-t border-border/70"><div className="mx-auto flex max-w-7xl flex-col gap-5 px-5 py-8 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between lg:px-8"><span className="logo-word text-base">GenZ<span>AI</span></span><div className="flex gap-5"><a href="#about" className="footer-link">Contact us</a><a href="#about" className="footer-link">Privacy policy</a><a href="#about" className="footer-link">Instagram</a></div><span className="font-mono">Built for the curious.</span></div></footer>
    </main>
  )
}
